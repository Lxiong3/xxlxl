package com;
//Author Lei Xiong
//Unit Test Class for Class Thing
import org.junit.Test;

public class ThingTest {
	Creature tiger = new Tiger("T");
	Thing grass = new Thing("Grass");
	
	@Test
	public void testToString(){
		System.out.println(tiger.toString());
		System.out.println(grass.toString());
	}
}
