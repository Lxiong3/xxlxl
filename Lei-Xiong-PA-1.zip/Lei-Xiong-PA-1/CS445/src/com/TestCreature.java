package com;



public class TestCreature {
	//create two viriables that counts for Things and Creatures
	public static int CREATURE_COUNT ;
	public static int THING_COUNT ;
	
	public TestCreature(){
		CREATURE_COUNT = 6;
		THING_COUNT = 10;
	}
	//create 10 Thing objects for testing
	
	
	public static void main(String []args){
		new TestCreature();
		Creature ant1 = new Ant("Tom");		
		Creature bat1 = new Bat("Tony the one");
		Creature bat2 = new Bat("Lei");
		Creature fly = new Fly("Peter");
		Creature tiger1 = new Tiger("Richard Parker");
		Creature tiger2 = new Tiger("Caesar");
		Thing oriange = new Thing("Oriange");
		Thing grass = new Thing("Grass");
		Thing apple = new Thing("Apple");
		Thing banana = new Thing("Banana");
		
		
		//create a Creature array storing creatures,a Thing array for storing things
		Creature [] creature = new Creature[CREATURE_COUNT];
		Thing [] t = new Thing[THING_COUNT];
		t[0] = ant1;
		t[1] = bat1;
		t[2] = bat2;
		t[3] = fly;
		t[4] = grass;
		t[5] = oriange;
		t[6] = banana;
		t[7] = tiger2;
		t[8] = tiger1;
		t[9] = apple;
		
		//Pick the creature elements out from the Thing array
		int k = 0;
		for(int i = 0; i<t.length;i++){
			
			if(t[i] instanceof Creature){
				
				creature[k] = ((Creature) t[i]);
//				System.out.println(k);
//				System.out.println(creature[k].name);
				k++;
			}
		
		}
		//print out  the classification results of creatures and things 
		System.out.println("Things:");
		System.out.println();
		for(int i = 0; i<t.length; i++){
			
			System.out.println(t[i].toString());
			
		}
		System.out.println();
		System.out.println("Creature:");
		System.out.println();
		for(int i = 0 ; i<creature.length; i++){
			
			System.out.println(creature[i].toString());
			
		}
		
		
	}
	
	
	
	
	
	
}
