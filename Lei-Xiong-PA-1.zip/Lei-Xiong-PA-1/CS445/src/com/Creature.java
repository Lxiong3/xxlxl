package com;
//Authro Lei Xiong
public abstract class Creature extends Thing {
	public Creature(String name) {
		super(name);			
	}
//create a Thing array of size 1 standing for stomach of creatures
	Thing[] S=new Thing[1];

	public void eat(Thing aThing){
		S[0]=aThing;		
		System.out.println(getClass().getSimpleName()+" has just eaten a "+aThing);
	}
	public abstract void move();
//Ask a creature what is the last thing it has ate	
	public void whatDidYouEat(){
		if(S[0]==null){
		  System.out.println(getClass().getSimpleName()+" has had nothing to eat!");	
		}else{
		  System.out.println(name+getClass().getSimpleName()+" has eaten a  "+S[0]);
		}
	};
	
}
