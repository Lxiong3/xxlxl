package com;
//Author Lei Xiong
public class Fly extends Creature implements Flyer {

	public Fly(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	public void eat(Thing aThing) {

		//Thing[] S = new Thing[1];

		if (aThing instanceof Creature) {
			System.out.println(name + getClass().getSimpleName() + "won't eat a" + aThing);
		} else {
			super.S[0] = aThing;
		}
	}

	@Override
	public void fly() {
		System.out.println(getClass().getSimpleName() + "is buzzing around in flight.");

	}
//when ask a Fly to move,it flies
	@Override
	public void move() {
		// TODO Auto-generated method stub
		this.fly();
	}

}
