package com;
//Author Lei Xiong
//Unit Test Class for Class Tiger
import org.junit.Test;

public class TigerTest {
	Tiger tiger1 = new Tiger("test");
	
	@Test
	public void TestMove() {
		System.out.println("Things moveing:");
		tiger1.move();
	}
	@Test
	public void TestTigerEat(){
		
			tiger1.eat(new Thing("Grass"));	
		
		
	}
	@Test
	public void TestTigerEatNothing(){
		tiger1.whatDidYouEat();
	}
}
