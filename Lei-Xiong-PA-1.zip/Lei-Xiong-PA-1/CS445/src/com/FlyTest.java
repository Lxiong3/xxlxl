package com;
//Author Lei Xiong
//Unit Test Class for Class Fly
import org.junit.Test;

public class FlyTest {
	Fly fly = new Fly("test");

	@Test
	public void TestMove() {
		System.out.println("Things moveing:");
		fly.move();
	}

	@Test
	public void TestFlyEat() {
		Creature c = new Bat("SmallBat");
		fly.eat(new Thing("Apple"));
		fly.eat(c);

	}

	@Test
	public void TestFlyEatNothing() {
		fly.whatDidYouEat();
	}
}
