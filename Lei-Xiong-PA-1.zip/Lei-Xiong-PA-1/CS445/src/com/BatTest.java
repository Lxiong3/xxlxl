package com;
//Author Lei Xiong
//Unit Test Class for Bat
import org.junit.Test;

public class BatTest {

	Bat bat1 = new Bat("test");

	@Test
	public void TestMove() {
		System.out.println("Things moveing:");
		bat1.move();
	}

	@Test
	public void TestBatEat() {
		Creature c = new Ant("WOlei");
		bat1.eat(new Thing("apple"));
		bat1.eat(c);
		bat1.whatDidYouEat();
		bat1.eat(new Thing(""));
	}

	@Test
	public void TestBatEatNothing() {
		bat1.whatDidYouEat();
	}
}
