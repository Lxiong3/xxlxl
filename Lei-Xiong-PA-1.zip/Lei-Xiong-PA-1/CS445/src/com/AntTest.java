package com;
//Author Lei Xiong
//Unit Test Class for Ant
import org.junit.Test;

public class AntTest {
	Ant ant1 = new Ant("test");

	@Test
	public void TestMove() {
		System.out.println("Things moveing:");
		ant1.move();
	}

	@Test
	public void TestAntEat() {
		ant1.eat(new Thing("apple"));
	}
	
	@Test
	public void TestWhatDidyouEat(){
		Creature c = new Tiger("Tom");
		ant1.eat(new Thing("apple"));
		ant1.eat(c);
		ant1.whatDidYouEat();

	}
	
	@Test
	public void TestAntEatNothing() {
		ant1.whatDidYouEat();
	}

}
