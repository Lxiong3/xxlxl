package com;
//author Lei Xiong
//Class Ant inherits Class Creature
public class Ant extends Creature {

	public Ant(String name) {
		super(name);
	}

	public void move() {
		System.out.println(name + " " + getClass().getSimpleName() + " is crawling around.");

	}

}
