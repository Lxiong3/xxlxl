package com;
//Authro Lei Xiong
public class Tiger extends Creature{

	public Tiger(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void move() {
		System.out.println(getClass().getSimpleName()+"has just pounced.");		
	}

}
