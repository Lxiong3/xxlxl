package com;

import org.junit.Test;

public class TestCreatureTest {
//	public static int CREATURE_COUNT;
//	public static int THING_COUNT ;
	
	
	//initialize a Creature array storing creatures,a Thing array for storing things
	@Test
	public void testTestCreature(){
		TestCreature.CREATURE_COUNT = 6;
		TestCreature.THING_COUNT = 10;
	}
	@Test
	public void testMain(){
		TestCreature.main(null);
	
	
}
}
