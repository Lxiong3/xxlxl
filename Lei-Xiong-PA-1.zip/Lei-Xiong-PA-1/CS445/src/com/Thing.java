package com;

public class Thing {
	public String name;
//Assign a name to each thing object	
	public Thing(String name){
		this.name=name;
	}
//This method let each object make a comment about themselves	
	public String toString(){
			if(!(this instanceof Creature)){
				return (name + " "+ getClass().getSimpleName());
			}else{
				return name;
		}
	}
	
}
