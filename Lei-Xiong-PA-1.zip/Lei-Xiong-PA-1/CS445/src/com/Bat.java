package com;

//Class Bat inherits Class Creature and uses Flyer interface
public class Bat extends Creature implements Flyer {

	public Bat(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	
	public void eat(Thing aThing) {
//Bat will not eat things that are not creatures
		if (!(aThing instanceof Creature)) {
			System.out.println(name + " " + getClass().getSimpleName() + " won't eat a " + aThing);
		} else  {		
//store the thing that can be eaten into its stomach
			super.S[0] = aThing;

		} 

	}

	@Override
	public void fly() {
		// TODO Auto-generated method stub
		System.out.println(name + " " + getClass().getSimpleName() + " is swooping through the dark.");
	}

	@Override
	public void move() {
		this.fly();

	}

}
