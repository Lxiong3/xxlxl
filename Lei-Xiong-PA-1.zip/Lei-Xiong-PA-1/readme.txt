{\rtf1\ansi\ansicpg936\cocoartf1404\cocoasubrtf470
{\fonttbl\f0\fswiss\fcharset0 Helvetica;}
{\colortbl;\red255\green255\blue255;}
\paperw11900\paperh16840\margl1440\margr1440\vieww10800\viewh8400\viewkind0
\pard\tx566\tx1133\tx1700\tx2267\tx2834\tx3401\tx3968\tx4535\tx5102\tx5669\tx6236\tx6803\pardirnatural\partightenfactor0

\f0\fs24 \cf0 1.This program is built under Eclipse IDE.\
\
2.The unit test plugin used to test the program is EclEmma2.3.3(EclEmma Java Code Coverage):\
To get the plugin, search EclEmma in EclipseMarketPlace then download and simply implement the plugin.\
\pard\tx566\tx1133\tx1700\tx2267\tx2834\tx3401\tx3968\tx4535\tx5102\tx5669\tx6236\tx6803\pardirnatural\partightenfactor0
\cf0 \
\pard\tx566\tx1133\tx1700\tx2267\tx2834\tx3401\tx3968\tx4535\tx5102\tx5669\tx6236\tx6803\pardirnatural\partightenfactor0
\cf0 3.There are no other special plugins that should be implemented to run this program.\
\
4.It consists of 13 classes:\
\
Thing.java\
ThingTest.java\
Creature.java\
TestCreature.java\
TestCreatureTest.java\
Ant.java\
AntTest.java\
Bat.java\
BatTest.java\
Fly.java\
FlyTest.java\
Tiger.java\
TigerTest.java\
\
and 1 interface : Flyer\
\
5.To run the program,firstly run the main() in TestCreature class,to test each method,use Junit to test them in each class with named ***test.java. The results would be shown in the console.\
\
}